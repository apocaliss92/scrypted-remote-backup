# Scrypted remote backup

https://github.com/apocaliss92/scrypted-remote-backup - For requests and bugs

This allow allows the backup of the scrypted server cron bases.

Supported services
- Local - backups are stored in the plugin folder
- SSFTP
- Samba

Use this link to calculate your cron string 
- https://crontab.guru/#0_5_*_*_* 
- https://www.npmjs.com/package/node-cron 